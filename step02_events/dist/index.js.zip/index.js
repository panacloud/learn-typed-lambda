/// <reference path="../typings/main.d.ts" />
exports.handler = function (event, context) {
    context.succeed("Hello " + event.username);
};
//# sourceMappingURL=index.js.map